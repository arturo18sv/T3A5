
package t3a5;


public class Cuenta {
    private String numeroCuenta;
    private int pin;
    private float saldo;
    
    public Cuenta(){}

    public Cuenta(String numeroCuenta, int pin, float saldo) {
        this.numeroCuenta = numeroCuenta;
        this.pin = pin;
        this.saldo = saldo;
       
    }

   public void consultarSaldo(){
      saldo = 850.87f;
   System.out.println("Tiene un saldo de:" + getSaldo());
           }
   
   public void estadoDeCuenta(){
      
       System.out.println("ESTADO DE CUENTA\n\n"
               + "Cuenta: " + numeroCuenta
               +"\nSaldo:" + saldo 
               +"\n\nUltimos movimientos");
   }
   
   public void retirarEfectivo(){
       if (getSaldo()>0){
           System.out.println("�Cuanto desae retirar?");
       }else{
           System.out.println("NO PUEDO AYUDARTE EN ESTA OPERACION"
                   + "\nFONDOS INSUFICIENTES");
       }
   }
   
   public void seguros(){
       System.out.println("SEGUROS"
               + "\n1. Seguro para tu auto"
               + "\n2. Seguro de vida"
               + "\n3. Seguro medico"
               + "\n4. Seguro de vivienda");
   }
   
   public void creditos(){
       System.out.println("CREDITOS"
               + "\n1. Hipotecario"
               + "\n2. Crediauto"
               + "\n3. Familiar"
               + "\n4. Personal");
   }

   public void salir(){
       System.out.println("Retirar tarjeta");
      
   }
   
   
   
    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public int getPin() {
        return pin;
    }

    public void setPin(int pin) {
        this.pin = pin;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    private String getNumeroCuenta() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
}
