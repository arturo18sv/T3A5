package t3a5;

 import java.util.Scanner;

public class T3A5 {

   
    public static void main(String[] args) {
        menu();
  }
    public static void menu(){
        Cuenta cuenta = new Cuenta();
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("BIENVENIDO A BANCO X\n"
                + "1. Consultar saldo\n"
                + "2. Retirar efectivo\n"
                + "3. Consultar estado de cuenta\n"
                + "4. Otras opciones\n"
                + "5. Salir"
                + "\n\nElija una operacion");
        
        
        
        int operacion = scanner.nextInt();
        
        switch(operacion){
            case 1:
            cuenta.consultarSaldo();
            break;
            
            case 2:
                cuenta.retirarEfectivo();
                break;
            
            case 3:
                cuenta.estadoDeCuenta();
                break;
                
            case 4:
                System.out.println("1 Seguros\n"
                        + "2. Cr�ditos\n\n"
                        + "Elija uno:");
                int opcion = scanner.nextInt();
                
                switch (opcion){
                    case 1:
                        cuenta.seguros();
                        break;
                        
                    case 2:
                        cuenta.creditos();
                        break;
                        
                    default:
                        System.out.println("Elija una opcion valida");
                        break;
                    
                  
                        
                    
                }
      
    }
}

    private static void consultarSaldo(){}
        
    }
        
   
       
    
